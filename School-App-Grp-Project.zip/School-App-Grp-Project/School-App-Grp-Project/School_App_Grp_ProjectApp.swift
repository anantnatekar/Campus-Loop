//
//  School_App_Grp_ProjectApp.swift
//  School-App-Grp-Project
//
//  Created by Anant Natekar on 2/25/23.
//

import SwiftUI

@main
struct School_App_Grp_ProjectApp: App {
    var body: some Scene {
        WindowGroup {
            SplashScreenView()
        }
    }
}
